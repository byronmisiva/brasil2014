<div class="panel panel-default panel-calendario">
    <div class="panel-body">
        <div class="row">
            <!--Calendarios y Grupos-->
            <div class="col-md-12">


                <!-- Nav tabs -->
                <ul class="nav nav-tabs movi-headline-regular tab-calendario">
                    <li class="active"><a href="#calendario" data-toggle="tab">
                            Fase de Grupos</a></li>

                </ul>
                <div class="clearfix"></div>

                <!-- Tab panes -->
                <div class="tab-content">
                    <div class="tab-pane fade in active" id="calendario">
                        <?php echo $tabComponent2; ?>
                    </div>

                </div>

            </div>
            <!--Fin Calendarios y Grupos-->
        </div>
    </div>
</div>

<div class="col-md-12 boton-more-fondo">
    <a href="#" class="boton-more">Ver detalles ></a>
</div>
<div class="clearfix"></div>
