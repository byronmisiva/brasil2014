<div class="row">
    <?php
    for ($i = 0; $i < 4; $i++) {
        ?>
        <div class="col-md-6 col-lg-6 col-sm-6 col-xs-6">
            <div class="col-md-12 cabecera">
                <span class="movi-headline-regular col-md-4 grupo">Grupo A</span>
                <span class="col-md-8">Lunes 14 de Junio 14h00</span>
            </div>
            <div class="col-md-12 cuerpo">
                <div class="row">
                    <div class="col-md-4 col-lg-4 col-sm-4 col-xs-4"><span
                            class="iconos sprite-brasil"/>BRA
                    </div>
                    <div class="col-md-4 col-lg-4 col-sm-4 col-xs-4">0&nbsp;&nbsp;vs&nbsp;&nbsp;0</div>
                    <div class="col-md-4 col-lg-4 col-sm-4 col-xs-4 pull-right"
                         style="text-align:right">ESP<span class="iconos sprite-espana right"/>
                    </div>
                </div>
            </div>
            <div class="col-md-12 cuerpo">
                <div class="row">
                    <div class="col-md-4 col-lg-4 col-sm-4 col-xs-4"><span
                            class="iconos sprite-croacia"/>CRO
                    </div>
                    <div class="col-md-4 col-lg-4 col-sm-4 col-xs-4">0&nbsp;&nbsp;vs&nbsp;&nbsp;0</div>
                    <div class="col-md-4 col-lg-4 col-sm-4 col-xs-4 pull-right"
                         style="text-align:right">NED<span class="iconos sprite-holanda"/></div>
                </div>
            </div>
        </div>
    <?php
    }
    ?>
</div>
