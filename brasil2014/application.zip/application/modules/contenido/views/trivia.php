<!-- Galería imágenes  -->
<div class="col-md-12 trivia separador">
    <div class="row">
        <div class="col-md-12 cabecera-partidos">
            <h2>
                <div class="iconos sprite-icono_trivia"></div>
                Trivia
            </h2>
        </div>
        <div class="col-md-12 movi-headline-regular titulo">Demuestra cuanto sabes de la historia de los mundiales, comparte tu resultado y desafía
            a tus amigos.
        </div>

        <div class="col-md-12 movi-headline-regular titulo">Pregunta 1 de 10</div>
        <div class="col-md-12 ">En el primer gol de Maradona contra Inglaterra en el Mundial de México 86..</div>
        <div class="col-md-12 ">
            <ul>
                <li>La asistencia fue de Jorge Valdano.</li>
                <li>Diego fue a festejarlo detrás del arco</li>
                <li>Argentina jugó con la camiseta suplente.</li>
                <li>Diego convirtió el tanto con la mano derecha</li>

            </ul>
        </div>
        <div class="col-md-12 text-right">
            Siguiente >
        </div>
    </div>


</div>
<!-- Fin  Galería imágenes  -->