<!-- Banner    -->

<div class="col-md-12 margen0 separador">
    <img src="<?php echo base_url('imagenes/temp/banner_horizontal.jpg') ?>" width="100%" class="img-responsive">
</div>

<div class="clearfix"></div>
<!-- Fin Banner   -->
