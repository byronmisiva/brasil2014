<div class="row">
    <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12 ">
        <a class="twitter-timeline" href="https://twitter.com/futbolecuador"
           data-widget-id="414086417094942720">Tweets por @futbolecuador</a>
        <script>!function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0], p = /^http:/.test(d.location) ? 'http' : 'https';
                if (!d.getElementById(id)) {
                    js = d.createElement(s);
                    js.id = id;
                    js.src = p + "://platform.twitter.com/widgets.js";
                    fjs.parentNode.insertBefore(js, fjs);
                }
            }(document, "script", "twitter-wjs");</script>
    </div>
</div>
<div class="separador"></div>
