<!-- Galería imágenes  -->
<div class="col-md-6 margen0 sedes">
    <div class="col-md-12 margen0l">
        <h2>
            <div class="iconos sprite-icono_sedes"></div>
            Sedes
        </h2>
        <hr class="cabecera">
    </div>
    <div class="clearfix"></div>
    <div id="carousel-example-generic2" class="carousel slide" data-ride="carousel">
        <!-- Controls -->
        <a  href="#carousel-example-generic" data-slide="prev" data-slide-to="0">
            <div class="col-md-6 gris">
                <
            </div>
        </a>
        <a  href="#carousel-example-generic" data-slide="next" data-slide-to="0">
            <div class="col-md-6 text-right gris">
                >
            </div>
        </a>
        <div class="clearfix"></div>
        <!-- Wrapper for slides -->
        <div class="carousel-inner">
            <div class="item active">
                <img src="<?php echo base_url('imagenes/sedes/sede1.png') ?>" alt="..." class="img-responsive margin-bottom-20">
                <div class="col-md-12 margen0l conten">
                    <h3>Río de Janeiro</h3>
                    Su incomparable belleza natural, su rica historia y la contagiosa alegría de vivir de los cariocas han
                    contribuido a hacer de Río un lugar apreciado en todo el mundo.
                </div>
            </div>
        <div class="item">
                <img src="<?php echo base_url('imagenes/sedes/sede1.png') ?>" alt="..." class="img-responsive margin-bottom-20">
                <div class="col-md-12 margen0l conten">
                    <h3>Otra sede</h3>
                    Detalle de la otra sede.
                </div>
            </div>

        </div>


    </div>
</div>
