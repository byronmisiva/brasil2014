<!-- Banner 300x250  -->

<div class="col-md-12">
    <img src="../imagenes/temp/banner2.jpg" width="100%" class="img-responsive">
</div>
<!-- Fin Banner 300x250  -->