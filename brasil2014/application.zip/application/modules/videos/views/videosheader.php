<div id="player"></div>

<!--        Contenidos principales-->
<!-- Tab panes -->
<div class="tab-content contenedor-videos">
    <div class="tab-pane fade in active" id="videos-contenedor">
        <div class="row">
            <div class="col-md-12">
                <div class="video ">
                    <img class="img-responsive center-block" src="<?php echo base_url('imagenes/temp/envivo.png'); ?>">
                </div>
            </div>
        </div>
    </div>
    <div class="tab-pane fade" id="otros-partidos">
        <div class="row">
            <div class="col-md-12">
                <img class="img-responsive center-block" src="<?php echo base_url('imagenes/temp/envivo.png'); ?>">
            </div>
        </div>

    </div>
    <div class="tab-pane fade" id="resumenes">
        <div class="row">
            <div class="col-md-12">
                <img class="img-responsive center-block" src="<?php echo base_url('imagenes/temp/envivo.png'); ?>">
            </div>
        </div>

    </div>
    <div class="tab-pane fade" id="contenido-exclusivo">
        <div class="row">
            <div class="col-md-12">
                <img class="img-responsive center-block" src="<?php echo base_url('imagenes/temp/envivo.png'); ?>">
            </div>
        </div>
    </div>
</div>

<!-- Nav tabs -->

<div class="margen15 video-text ">No te pierdas ningún partido, vívelos nuevamente con Movistar</div>
<div id="videos-contenedor-carrousel" class="list_carousel_header">
    <a id="prev2" class="prev" href="#"><span class="glyphicon glyphicon-chevron-left"></span></a>
    <ul id="foo2" class="foo">
        <li>
            <img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria1.png'); ?>" alt="">
            <div class="video-mini-part1 text-center">BRA - CRO</div>
            <div class="video-mini-part2 text-center">Junio 16/14h00</div>

        </li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria2.png'); ?>" alt=""><div class="video-mini-part1 text-center">BRA - CRO</div>
            <div class="video-mini-part2 text-center">Junio 16/14h00</div>
        </li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria3.png'); ?>" alt=""><div class="video-mini-part1 text-center">BRA - CRO</div>
            <div class="video-mini-part2 text-center">Junio 16/14h00</div>
        </li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria4.png'); ?>" alt=""><div class="video-mini-part1 text-center">BRA - CRO</div>
            <div class="video-mini-part2 text-center">Junio 16/14h00</div>
        </li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria5.png'); ?>" alt=""><div class="video-mini-part1 text-center">BRA - CRO</div>
            <div class="video-mini-part2 text-center">Junio 16/14h00</div>
        </li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria6.png'); ?>" alt=""><div class="video-mini-part1 text-center">BRA - CRO</div>
            <div class="video-mini-part2 text-center">Junio 16/14h00</div>
        </li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria7.png'); ?>" alt=""><div class="video-mini-part1 text-center">BRA - CRO</div>
            <div class="video-mini-part2 text-center">Junio 16/14h00</div>
        </li>
    </ul>
    <a id="next2" class="next" href="#"><span class="glyphicon glyphicon-chevron-right"></span></a>

    <div class="col-md-12 boton-more-fondo">
        <a href="#" class="boton-more">Ver más vídeos ></a>
    </div>
    <div class="clearfix"></div>
</div>

<div id="otros-partidos-carrousel" class="list_carousel_header">
    <a id="prev4" class="prev" href="#"><span class="glyphicon glyphicon-chevron-left"></span></a>
    <ul id="foo4" class="foo">
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
    </ul>
    <a id="next4" class="next" href="#"><span class="glyphicon glyphicon-chevron-right"></span></a>

    <div class="clearfix"></div>
</div>
<div id="resumenes-carrousel" class="list_carousel_header">
    <a id="prev5" class="prev" href="#"><span class="glyphicon glyphicon-chevron-left"></span></a>
    <ul id="foo5" class="foo">
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria1.png'); ?>" alt=""></li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria2.png'); ?>" alt=""></li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria3.png'); ?>" alt=""></li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria4.png'); ?>" alt=""></li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria5.png'); ?>" alt=""></li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria6.png'); ?>" alt=""></li>
        <li><img class="media-object" src="<?php echo base_url('imagenes/galerias/thum-galeria7.png'); ?>" alt=""></li>
    </ul>
    <a id="next5" class="next" href="#"><span class="glyphicon glyphicon-chevron-right"></span></a>

    <div class="clearfix"></div>
</div>
<div id="contenido-exclusivo-carrousel" class="list_carousel_header">
    <a id="prev6" class="prev" href="#"><span class="glyphicon glyphicon-chevron-left"></span></a>
    <ul id="foo6" class="foo">
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
        <li><img class="media-object img-responsive" src="<?php echo base_url('imagenes/galerias/thum-galeria1-b.png'); ?>" alt="">
        </li>
    </ul>
    <a id="next6" class="next" href="#"><span class="glyphicon glyphicon-chevron-right"></span></a>

    <div class="clearfix"></div>
</div>

 
