<div class="btn-group btn-group-justified  grupos movi-text-regular" id="inicio">
    <div class="btn-group ">
        <a href="#" onclick="$('#grupo-a').animatescroll();">
            <button type="button" class="btn btn-default">Grupo A</button>
        </a>
    </div>
    <div class="btn-group  ">
        <a href="#" onclick="$('#grupo-b').animatescroll();">
            <button type="button" class="btn btn-default">Grupo B</button>
        </a>
    </div>
    <div class="btn-group ">
        <a href="#" onclick="$('#grupo-c').animatescroll();">
            <button type="button" class="btn btn-default">Grupo C</button>
        </a>
    </div>
    <div class="btn-group ">
        <a href="#" onclick="$('#grupo-d').animatescroll();">
            <button type="button" class="btn btn-default">Grupo D</button>
        </a>
    </div>
    <div class="btn-group ">
        <a href="#" onclick="$('#grupo-e').animatescroll();">
            <button type="button" class="btn btn-default">Grupo E</button>
        </a>
    </div>
    <div class="btn-group ">
        <a href="#" onclick="$('#grupo-f').animatescroll();">
            <button type="button" class="btn btn-default">Grupo F</button>
        </a>
    </div>
    <div class="btn-group ">
        <a href="#" onclick="$('#grupo-g').animatescroll();">
            <button type="button" class="btn btn-default">Grupo G</button>
        </a>
    </div>
    <div class="btn-group ">
        <a href="#" onclick="$('#grupo-h').animatescroll();">
            <button type="button" class="btn btn-default">Grupo H</button>
        </a>
    </div>
</div>