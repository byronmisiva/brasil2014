
/**
 * Base js file
 */
$(document).ready(function(){
    //Start carousel
    $('.carousel').carousel({interval:false});
    http://localhost:10088/brasil2014/lazy-load-bootstrap-carousel/

        $('.estadio-banner').carousel({interval:false});

});